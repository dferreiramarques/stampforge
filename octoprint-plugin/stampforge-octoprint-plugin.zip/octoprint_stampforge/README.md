# StampForge — OctoPrint Plugin

Browser-based fabric stamp designer, integrated directly into OctoPrint as a native tab.

---

## Installation

### Linux (Mint, Ubuntu, Debian, Raspberry Pi OS)
```bash
chmod +x install.sh
./install.sh
```

### Windows
Double-click `install.bat`  
(Run as Administrator if it fails)

### macOS
Double-click `install.command`  
(If blocked by Gatekeeper: right-click → Open)

---

## After installation

1. Restart OctoPrint (the installer offers to do this automatically)
2. Open OctoPrint in your browser
3. A **StampForge** tab appears in the top navigation
4. Design your stamp, click **▶ PRINT** — done

No API key, no CORS, no separate server.  
The plugin communicates internally with OctoPrint's printer connection.

---

## Requirements

| Component | Minimum version |
|---|---|
| OctoPrint | 1.8.0 |
| Python | 3.7 |
| Browser (for USB print) | Chrome or Edge |

---

## Uninstall

OctoPrint → Settings → Plugin Manager → StampForge → Uninstall

---

*Developed by vibe coding with claude.ai — Centro de Inovação Carlos Fiolhais / CDI Portugal — Março 2026*
