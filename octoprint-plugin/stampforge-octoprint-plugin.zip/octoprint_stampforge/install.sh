#!/usr/bin/env bash
# ══════════════════════════════════════════════════════
#  StampForge — OctoPrint Plugin Installer
#  Linux Mint / Ubuntu / Debian
# ══════════════════════════════════════════════════════
set -e

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  StampForge — OctoPrint Plugin Installer"
echo "  CDI Portugal / Centro de Inovação Carlos Fiolhais"
echo ""

# ── Find OctoPrint Python environment ─────────────────
OCTO_PY=""
CANDIDATES=(
  "$HOME/.local/share/OctoPrint/venv/bin/python"
  "$HOME/OctoPrint/venv/bin/python"
  "/home/pi/oprint/bin/python"
  "$(which python3 2>/dev/null)"
)

for py in "${CANDIDATES[@]}"; do
  if [ -f "$py" ] && "$py" -c "import octoprint" 2>/dev/null; then
    OCTO_PY="$py"
    break
  fi
done

if [ -z "$OCTO_PY" ]; then
  echo "  [!] OctoPrint Python environment not found."
  echo "  [!] Trying default python3 — you may need to activate your venv first."
  OCTO_PY="python3"
fi

echo "  [✓] Using Python: $OCTO_PY"
echo "  [✓] OctoPrint version: $($OCTO_PY -c 'import octoprint; print(octoprint.__version__)' 2>/dev/null || echo 'unknown')"

# ── Install plugin ─────────────────────────────────────
echo ""
echo "  Installing StampForge plugin..."
"$OCTO_PY" -m pip install --no-deps "$PLUGIN_DIR" --force-reinstall

echo ""
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║  StampForge plugin installed!                    ║"
echo "  ║                                                  ║"
echo "  ║  Restart OctoPrint to activate:                  ║"
echo "  ║    sudo systemctl restart octoprint              ║"
echo "  ║  or restart via OctoPrint Settings → Server      ║"
echo "  ║                                                  ║"
echo "  ║  After restart, find the StampForge tab          ║"
echo "  ║  in the OctoPrint interface.                     ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo ""

read -p "  Restart OctoPrint now? [y/N] " ans
if [[ "${ans,,}" == "y" ]]; then
  if command -v systemctl &>/dev/null && systemctl is-active --quiet octoprint 2>/dev/null; then
    sudo systemctl restart octoprint
    echo "  [✓] OctoPrint restarted."
  else
    echo "  [!] Could not auto-restart — please restart OctoPrint manually."
  fi
fi
