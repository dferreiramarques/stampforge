# coding=utf-8
import octoprint.plugin
import octoprint.filemanager
import octoprint.filemanager.util
import flask
import io


class StampforgePlugin(
    octoprint.plugin.SettingsPlugin,
    octoprint.plugin.AssetPlugin,
    octoprint.plugin.TemplatePlugin,
    octoprint.plugin.BlueprintPlugin,
):

    def get_settings_defaults(self):
        return dict(auto_select=True, auto_print=True)

    def get_assets(self):
        return dict(js=["js/stampforge.js"], css=["css/stampforge.css"])

    def get_template_configs(self):
        return [dict(type="tab", name="StampForge",
                     template="stampforge_tab.jinja2", custom_bindings=False)]

    def get_template_vars(self):
        return dict(api_key=self._settings.global_get(["api", "key"]))

    def is_blueprint_csrf_protected(self):
        return False

    @octoprint.plugin.BlueprintPlugin.route("/print", methods=["POST"])
    def handle_print(self):
        if not flask.request.json:
            return flask.make_response(flask.jsonify({"error": "No JSON"}), 400)

        data     = flask.request.json
        filename = data.get("filename", "stampforge.gcode")
        gcode    = data.get("gcode", "")

        if not gcode:
            return flask.make_response(flask.jsonify({"error": "Empty GCODE"}), 400)

        safe_name = "".join(
            c for c in filename if c.isalnum() or c in "._-"
        ).strip() or "stampforge.gcode"
        if not safe_name.endswith(".gcode"):
            safe_name += ".gcode"

        self._logger.info("StampForge: received %s (%d chars)", safe_name, len(gcode))

        try:
            stream = octoprint.filemanager.util.StreamWrapper(
                safe_name, io.BytesIO(gcode.encode("utf-8"))
            )
            self._file_manager.add_file(
                octoprint.filemanager.FileDestinations.LOCAL,
                safe_name,
                stream,
                allow_overwrite=True,
            )
            self._logger.info("StampForge: uploaded %s", safe_name)

            if self._settings.get(["auto_select"]):
                self._printer.select_file(
                    safe_name,
                    sd=False,
                    printAfterSelect=bool(self._settings.get(["auto_print"])),
                )

            return flask.jsonify({"status": "ok", "filename": safe_name,
                                  "lines": gcode.count("\n")})
        except Exception as e:
            self._logger.exception("StampForge error: %s", e)
            return flask.make_response(flask.jsonify({"error": str(e)}), 500)

    def get_update_information(self):
        return dict(stampforge=dict(
            displayName="StampForge", displayVersion=self._plugin_version,
            type="github_release", user="cicf-portugal", repo="stampforge",
            current=self._plugin_version,
        ))


__plugin_name__           = "StampForge"
__plugin_version__        = "3.0.0"
__plugin_description__    = "Browser-based stamp designer with direct 3D print integration."
__plugin_author__         = "CDI Portugal / Centro de Inovação Carlos Fiolhais"
__plugin_license__        = "MIT"
__plugin_pythoncompat__   = ">=3.7,<4"
__plugin_implementation__ = StampforgePlugin()
