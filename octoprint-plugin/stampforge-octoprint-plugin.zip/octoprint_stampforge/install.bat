@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul

echo.
echo   StampForge — OctoPrint Plugin Installer
echo   CDI Portugal / Centro de Inovação Carlos Fiolhais
echo.

:: ── Find OctoPrint Python environment ─────────────────
set OCTO_PY=

:: Common OctoPrint venv locations on Windows
set CANDIDATES[0]=%APPDATA%\OctoPrint\venv\Scripts\python.exe
set CANDIDATES[1]=%USERPROFILE%\OctoPrint\venv\Scripts\python.exe
set CANDIDATES[2]=%LOCALAPPDATA%\OctoPrint\venv\Scripts\python.exe
set CANDIDATES[3]=%PROGRAMFILES%\OctoPrint\venv\Scripts\python.exe

for /L %%i in (0,1,3) do (
    if defined CANDIDATES[%%i] (
        if exist "!CANDIDATES[%%i]!" (
            "!CANDIDATES[%%i]!" -c "import octoprint" >nul 2>&1
            if !errorlevel! == 0 (
                set OCTO_PY=!CANDIDATES[%%i]!
                goto :found_py
            )
        )
    )
)

:: Fallback to system python
python -c "import octoprint" >nul 2>&1
if %errorlevel% == 0 (
    set OCTO_PY=python
    goto :found_py
)

echo   [!] OctoPrint Python environment not found.
echo   [!] Make sure OctoPrint is installed, or activate your venv first.
echo   [!] Trying system python3 as fallback...
set OCTO_PY=python

:found_py
echo   [OK] Using Python: %OCTO_PY%

:: Get OctoPrint version
for /f "delims=" %%v in ('"%OCTO_PY%" -c "import octoprint; print(octoprint.__version__)" 2^>nul') do (
    echo   [OK] OctoPrint version: %%v
)

:: ── Install plugin ─────────────────────────────────────
echo.
echo   Installing StampForge plugin...
echo.

"%OCTO_PY%" -m pip install --no-deps "%~dp0" --force-reinstall

if %errorlevel% neq 0 (
    echo.
    echo   [ERROR] Installation failed.
    echo   [!] Try running this script as Administrator.
    pause
    exit /b 1
)

echo.
echo   ╔══════════════════════════════════════════════════╗
echo   ║  StampForge plugin installed!                    ║
echo   ║                                                  ║
echo   ║  Restart OctoPrint to activate:                  ║
echo   ║    - OctoPrint Settings ^> Server ^> Restart       ║
echo   ║    - Or restart the OctoPrint service/app        ║
echo   ║                                                  ║
echo   ║  After restart, find the StampForge tab          ║
echo   ║  in the OctoPrint interface.                     ║
echo   ║                                                  ║
echo   ║  NOTE: For USB printing via Web Serial,          ║
echo   ║  use Chrome or Edge (not Firefox).               ║
echo   ╚══════════════════════════════════════════════════╝
echo.

:: Try to restart OctoPrint Windows service if running as service
sc query OctoPrint >nul 2>&1
if %errorlevel% == 0 (
    set /p RESTART="  Restart OctoPrint service now? [y/N] "
    if /i "!RESTART!" == "y" (
        net stop OctoPrint >nul 2>&1
        net start OctoPrint >nul 2>&1
        echo   [OK] OctoPrint restarted.
    )
) else (
    echo   Restart OctoPrint manually via its interface.
)

echo.
pause
