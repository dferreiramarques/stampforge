#!/usr/bin/env bash
# ══════════════════════════════════════════════════════
#  StampForge — OctoPrint Plugin Installer
#  macOS (Intel + Apple Silicon)
# ══════════════════════════════════════════════════════
set -e

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  StampForge — OctoPrint Plugin Installer"
echo "  CDI Portugal / Centro de Inovação Carlos Fiolhais"
echo ""

# ── Find OctoPrint Python environment ─────────────────
OCTO_PY=""
CANDIDATES=(
    # OctoPrint.app (official macOS bundle)
    "/Applications/OctoPrint.app/Contents/MacOS/python"
    "/Applications/OctoPrint.app/Contents/Resources/venv/bin/python3"
    # Manual venv installs
    "$HOME/Library/Application Support/OctoPrint/venv/bin/python3"
    "$HOME/.octoprint/venv/bin/python3"
    "$HOME/OctoPrint/venv/bin/python3"
    # Homebrew
    "/opt/homebrew/bin/python3"
    "/usr/local/bin/python3"
    # System fallback
    "$(which python3 2>/dev/null)"
)

for py in "${CANDIDATES[@]}"; do
    if [ -f "$py" ] && "$py" -c "import octoprint" 2>/dev/null; then
        OCTO_PY="$py"
        break
    fi
done

if [ -z "$OCTO_PY" ]; then
    echo "  [!] OctoPrint Python environment not found."
    echo "  [!] Trying system python3 as fallback..."
    OCTO_PY="python3"
fi

echo "  [✓] Using Python: $OCTO_PY"
OCTO_VER=$("$OCTO_PY" -c "import octoprint; print(octoprint.__version__)" 2>/dev/null || echo "unknown")
echo "  [✓] OctoPrint version: $OCTO_VER"

# ── Check for Rosetta if Apple Silicon ────────────────
ARCH=$(uname -m)
if [ "$ARCH" = "arm64" ]; then
    echo "  [✓] Apple Silicon detected (M-series)"
fi

# ── Install plugin ─────────────────────────────────────
echo ""
echo "  Installing StampForge plugin..."
"$OCTO_PY" -m pip install --no-deps "$PLUGIN_DIR" --force-reinstall

echo ""
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║  StampForge plugin installed!                    ║"
echo "  ║                                                  ║"
echo "  ║  Restart OctoPrint to activate:                  ║"
echo "  ║    - OctoPrint Settings → Server → Restart       ║"
echo "  ║    - Or quit and reopen OctoPrint.app            ║"
echo "  ║                                                  ║"
echo "  ║  After restart, find the StampForge tab          ║"
echo "  ║  in the OctoPrint interface.                     ║"
echo "  ║                                                  ║"
echo "  ║  NOTE: For USB printing via Web Serial,          ║"
echo "  ║  use Chrome or Edge (Safari not supported).      ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo ""

# ── Restart OctoPrint.app if running ──────────────────
if pgrep -x "OctoPrint" > /dev/null 2>&1; then
    read -p "  Restart OctoPrint now? [y/N] " ans
    if [[ "${ans,,}" == "y" ]]; then
        pkill -x "OctoPrint" 2>/dev/null || true
        sleep 1
        if [ -d "/Applications/OctoPrint.app" ]; then
            open "/Applications/OctoPrint.app"
            echo "  [✓] OctoPrint restarted."
        else
            echo "  [!] Restart OctoPrint manually."
        fi
    fi
elif command -v brew &>/dev/null && brew services list | grep -q "octoprint"; then
    read -p "  Restart OctoPrint brew service? [y/N] " ans
    if [[ "${ans,,}" == "y" ]]; then
        brew services restart octoprint
        echo "  [✓] OctoPrint restarted."
    fi
else
    echo "  Restart OctoPrint manually via its interface."
fi

echo ""
