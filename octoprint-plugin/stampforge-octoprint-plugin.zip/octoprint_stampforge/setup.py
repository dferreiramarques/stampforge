#!/usr/bin/env python
# coding=utf-8

from setuptools import setup, find_packages

setup(
    name="OctoPrint-StampForge",
    version="3.0.0",
    description="Browser-based stamp designer with direct 3D print integration",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="CDI Portugal / Centro de Inovação Carlos Fiolhais",
    author_email="inovacao@cdi.pt",
    url="https://github.com/cicf-portugal/stampforge",
    license="MIT",
    python_requires=">=3.7,<4",
    packages=find_packages(),
    package_data={
        "octoprint_stampforge": [
            "templates/*.jinja2",
            "static/js/*.js",
            "static/css/*.css",
        ]
    },
    install_requires=["OctoPrint>=1.8.0"],
    entry_points={
        "octoprint.plugin": [
            "stampforge = octoprint_stampforge"
        ]
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Web Environment",
        "Framework :: Flask",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Printing",
    ],
)
