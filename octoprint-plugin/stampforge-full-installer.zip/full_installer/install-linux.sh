#!/usr/bin/env bash
# ══════════════════════════════════════════════════════
#  StampForge + OctoPrint — Full Installer
#  Linux Mint, Ubuntu 22+, Debian 12+, Raspberry Pi OS
# ══════════════════════════════════════════════════════
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.local/share/OctoPrint"
VENV="$INSTALL_DIR/venv"
PORT=5000

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}[✓]${NC} $1"; }
warn() { echo -e "  ${YELLOW}[!]${NC} $1"; }
info() { echo -e "  ${CYAN}[…]${NC} $1"; }
err()  { echo -e "  ${RED}[✗]${NC} $1"; }

echo ""
echo -e "  ${CYAN}██████ ████████  █████  ███    ███ ██████  ███████  ██████  ██████   ██████  ███████${NC}"
echo -e "  ${CYAN}StampForge + OctoPrint — Full Installer${NC}"
echo -e "  CDI Portugal / Centro de Inovação Carlos Fiolhais"
echo ""

# ── Check not root ─────────────────────────────────────
if [ "$EUID" -eq 0 ]; then
    warn "Running as root is not recommended. Run as your normal user."
    read -p "  Continue anyway? [y/N] " ans
    [[ "${ans,,}" != "y" ]] && exit 1
fi

# ── System dependencies ────────────────────────────────
info "Checking system dependencies..."
PKGS=()
command -v python3 &>/dev/null || PKGS+=(python3)
command -v pip3    &>/dev/null || PKGS+=(python3-pip)
python3 -c "import venv" 2>/dev/null   || PKGS+=(python3-venv)
python3 -c "import dev"  2>/dev/null   || PKGS+=(python3-dev)
command -v git     &>/dev/null || PKGS+=(git)

# Check for build essentials (needed for some OctoPrint deps)
dpkg -l build-essential &>/dev/null || PKGS+=(build-essential)
dpkg -l libyaml-dev     &>/dev/null || PKGS+=(libyaml-dev)

if [ ${#PKGS[@]} -gt 0 ]; then
    info "Installing: ${PKGS[*]}"
    sudo apt-get update -qq
    sudo apt-get install -y -qq "${PKGS[@]}"
fi
ok "System dependencies ready"

# ── USB Serial permissions ─────────────────────────────
if ! groups | grep -q dialout; then
    info "Adding $USER to dialout group (required for USB printing)..."
    sudo usermod -a -G dialout "$USER"
    warn "Log out and back in after install for USB to work."
else
    ok "dialout group: OK"
fi

# ── Create OctoPrint venv ──────────────────────────────
if [ ! -d "$VENV" ]; then
    info "Creating Python virtual environment at $VENV..."
    mkdir -p "$INSTALL_DIR"
    python3 -m venv "$VENV"
    ok "Virtual environment created"
else
    ok "Virtual environment exists: $VENV"
fi

PY="$VENV/bin/python"
PIP="$VENV/bin/pip"

# ── Install / upgrade OctoPrint ───────────────────────
info "Installing OctoPrint (this may take a few minutes)..."
"$PIP" install --upgrade pip setuptools wheel -q
"$PIP" install "OctoPrint>=1.9.0" -q
OCTO_VER=$("$PY" -c "import octoprint; print(octoprint.__version__)")
ok "OctoPrint $OCTO_VER installed"

# ── Install StampForge plugin ──────────────────────────
info "Installing StampForge plugin..."
"$PIP" install --no-deps "$SCRIPT_DIR/plugin" --force-reinstall -q
ok "StampForge plugin installed"

# ── Create systemd service ─────────────────────────────
SERVICE_FILE="/etc/systemd/system/octoprint.service"
if command -v systemctl &>/dev/null; then
    info "Creating systemd service..."
    sudo tee "$SERVICE_FILE" > /dev/null << SVCEOF
[Unit]
Description=OctoPrint + StampForge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
ExecStart=$VENV/bin/octoprint serve --port $PORT
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF
    sudo systemctl daemon-reload
    sudo systemctl enable octoprint
    ok "Systemd service created (octoprint)"
fi

# ── Desktop launcher ───────────────────────────────────
DESKTOP="$HOME/.local/share/applications/octoprint-stampforge.desktop"
mkdir -p "$HOME/.local/share/applications"
cat > "$DESKTOP" << DESKEOF
[Desktop Entry]
Version=1.0
Type=Application
Name=StampForge
GenericName=3D Stamp Designer + OctoPrint
Comment=Design and print fabric stamps — CDI Portugal
Exec=xdg-open http://localhost:$PORT
Icon=$SCRIPT_DIR/icon.svg
Terminal=false
Categories=Graphics;3DGraphics;Education;
DESKEOF
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
ok "Desktop launcher created"

# ── Shell alias ────────────────────────────────────────
ALIAS_LINE="alias stampforge='$VENV/bin/octoprint serve --port $PORT &>/dev/null & sleep 3 && xdg-open http://localhost:$PORT'"
for rcfile in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$rcfile" ] && ! grep -q "alias stampforge=" "$rcfile"; then
        echo "" >> "$rcfile"
        echo "# StampForge + OctoPrint" >> "$rcfile"
        echo "$ALIAS_LINE" >> "$rcfile"
    fi
done
ok "Shell alias 'stampforge' added"

echo ""
echo -e "  ${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "  ${GREEN}║  Installation complete!                          ║${NC}"
echo -e "  ${GREEN}║                                                  ║${NC}"
echo -e "  ${GREEN}║  Start:  sudo systemctl start octoprint          ║${NC}"
echo -e "  ${GREEN}║  Open:   http://localhost:$PORT                     ║${NC}"
echo -e "  ${GREEN}║  Or run: stampforge  (new terminal)              ║${NC}"
echo -e "  ${GREEN}║                                                  ║${NC}"
echo -e "  ${GREEN}║  First run: OctoPrint setup wizard appears.      ║${NC}"
echo -e "  ${GREEN}║  After setup → StampForge tab is visible.        ║${NC}"
echo -e "  ${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

read -p "  Start OctoPrint now? [Y/n] " ans
if [[ "${ans,,}" != "n" ]]; then
    if command -v systemctl &>/dev/null; then
        sudo systemctl start octoprint
        sleep 3
        ok "OctoPrint started"
    else
        "$VENV/bin/octoprint" serve --port $PORT &
        sleep 3
    fi
    xdg-open "http://localhost:$PORT" 2>/dev/null || \
        echo -e "  Open: ${CYAN}http://localhost:$PORT${NC}"
fi
echo ""
