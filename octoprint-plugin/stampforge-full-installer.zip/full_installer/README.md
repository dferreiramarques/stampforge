# StampForge + OctoPrint — Full Installer

Installs OctoPrint + StampForge plugin in one step.  
No prior OctoPrint installation required.

---

## Quick start

### Linux (Mint, Ubuntu, Debian, Raspberry Pi OS)
```bash
chmod +x install-linux.sh
./install-linux.sh
```

### Windows 10/11
Right-click `install-windows.ps1` → **Run with PowerShell as Administrator**  
(Or: `powershell -ExecutionPolicy Bypass -File install-windows.ps1`)

### macOS (Monterey, Ventura, Sonoma — Intel + Apple Silicon)
Double-click `install-macos.command`  
(If blocked: right-click → Open)

---

## What gets installed

| Component | Version |
|---|---|
| OctoPrint | ≥ 1.9.0 |
| StampForge plugin | 3.0.0 |
| Python venv | isolated, does not affect system Python |

## What the installer does

**Linux**
- Installs system deps (`python3-venv`, `build-essential`, etc.)
- Creates venv at `~/.local/share/OctoPrint/venv`
- Installs OctoPrint + StampForge
- Creates systemd service (auto-start on boot)
- Creates desktop launcher + shell alias

**Windows**
- Downloads + installs Python 3.11 if needed
- Creates venv at `%LOCALAPPDATA%\OctoPrint\venv`
- Installs OctoPrint + StampForge
- Creates Desktop shortcut + Start Menu entry
- Adds Windows Firewall rule for port 5000

**macOS**
- Installs Homebrew + Python 3.11 if needed
- Creates venv at `~/Library/Application Support/OctoPrint/venv`
- Installs OctoPrint + StampForge
- Creates `~/Applications/StampForge.app`
- Creates launchd service + shell alias

---

## After installation

1. Open `http://localhost:5000` in Chrome or Edge
2. Complete the OctoPrint first-run wizard
3. The **StampForge** tab appears in the OctoPrint navigation
4. Design your stamp → click **▶ PRINT**

---

## Uninstall

**Linux:** `sudo systemctl disable octoprint && rm -rf ~/.local/share/OctoPrint`  
**Windows:** Delete `%LOCALAPPDATA%\OctoPrint` and the Desktop shortcut  
**macOS:** `rm -rf ~/Applications/StampForge.app ~/Library/Application\ Support/OctoPrint`

---

## Versions

| Build | Features |
|---|---|
| **Local (this installer)** | Draw + SVG + STL + GCODE + Layer preview + USB print + OctoPrint |
| **Free / Railway** | Draw + SVG + STL only |

---

*Developed by vibe coding with claude.ai — Centro de Inovação Carlos Fiolhais / CDI Portugal — Março 2026*
