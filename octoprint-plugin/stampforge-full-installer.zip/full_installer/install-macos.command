#!/usr/bin/env bash
# ══════════════════════════════════════════════════════
#  StampForge + OctoPrint — Full Installer
#  macOS 12+ (Monterey, Ventura, Sonoma) — Intel + Apple Silicon
# ══════════════════════════════════════════════════════
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/Library/Application Support/OctoPrint"
VENV="$INSTALL_DIR/venv"
PORT=5000
ARCH=$(uname -m)

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}[✓]${NC} $1"; }
warn() { echo -e "  ${YELLOW}[!]${NC} $1"; }
info() { echo -e "  ${CYAN}[…]${NC} $1"; }

echo ""
echo -e "  ${CYAN}StampForge + OctoPrint — Full Installer${NC}"
echo "  CDI Portugal / Centro de Inovação Carlos Fiolhais"
echo "  Platform: macOS ($ARCH)"
echo ""

# ── Check Xcode Command Line Tools ────────────────────
if ! xcode-select -p &>/dev/null; then
    info "Installing Xcode Command Line Tools (required)..."
    xcode-select --install
    echo "  Please complete the Xcode tools installation, then re-run this script."
    exit 0
fi
ok "Xcode CLT: OK"

# ── Check / Install Homebrew ──────────────────────────
if ! command -v brew &>/dev/null; then
    info "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    # Add brew to PATH for Apple Silicon
    if [ "$ARCH" = "arm64" ]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
    fi
fi
ok "Homebrew: $(brew --version | head -1)"

# ── Check / Install Python 3 ──────────────────────────
if ! command -v python3 &>/dev/null || ! python3 -c "import sys; assert sys.version_info >= (3,8)" 2>/dev/null; then
    info "Installing Python 3.11 via Homebrew..."
    brew install python@3.11
fi
PY3=$(command -v python3.11 || command -v python3)
ok "Python: $($PY3 --version)"

# ── Create venv ────────────────────────────────────────
if [ ! -d "$VENV" ]; then
    info "Creating virtual environment..."
    mkdir -p "$INSTALL_DIR"
    "$PY3" -m venv "$VENV"
    ok "Virtual environment created: $VENV"
else
    ok "Virtual environment exists"
fi

PY="$VENV/bin/python"
PIP="$VENV/bin/pip"

# ── Install OctoPrint ─────────────────────────────────
info "Installing OctoPrint (this may take a few minutes)..."
"$PIP" install --upgrade pip setuptools wheel -q
"$PIP" install "OctoPrint>=1.9.0" -q
OCTO_VER=$("$PY" -c "import octoprint; print(octoprint.__version__)")
ok "OctoPrint $OCTO_VER installed"

# ── Install StampForge plugin ──────────────────────────
info "Installing StampForge plugin..."
"$PIP" install --no-deps "$SCRIPT_DIR/plugin" --force-reinstall -q
ok "StampForge plugin installed"

# ── Create launchd plist (auto-start) ─────────────────
PLIST="$HOME/Library/LaunchAgents/com.cicf.stampforge.plist"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" << PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.cicf.stampforge</string>
    <key>ProgramArguments</key>
    <array>
        <string>$VENV/bin/octoprint</string>
        <string>serve</string>
        <string>--port</string>
        <string>$PORT</string>
    </array>
    <key>RunAtLoad</key>
    <false/>
    <key>KeepAlive</key>
    <false/>
    <key>StandardOutPath</key>
    <string>$HOME/Library/Logs/stampforge.log</string>
    <key>StandardErrorPath</key>
    <string>$HOME/Library/Logs/stampforge.log</string>
</dict>
</plist>
PLISTEOF
launchctl load "$PLIST" 2>/dev/null || true
ok "launchd service created"

# ── Create app launcher script ────────────────────────
LAUNCHER="$INSTALL_DIR/start-stampforge.sh"
cat > "$LAUNCHER" << LAUNCHEOF
#!/bin/bash
# Start StampForge + OctoPrint
if pgrep -f "octoprint serve" > /dev/null; then
    open http://localhost:$PORT
else
    "$VENV/bin/octoprint" serve --port $PORT &>/dev/null &
    sleep 4
    open http://localhost:$PORT
fi
LAUNCHEOF
chmod +x "$LAUNCHER"

# ── Create macOS .app bundle ──────────────────────────
APP_DIR="$HOME/Applications/StampForge.app"
mkdir -p "$APP_DIR/Contents/MacOS"
mkdir -p "$APP_DIR/Contents/Resources"

cat > "$APP_DIR/Contents/MacOS/StampForge" << APPEOF
#!/bin/bash
"$LAUNCHER"
APPEOF
chmod +x "$APP_DIR/Contents/MacOS/StampForge"

cat > "$APP_DIR/Contents/Info.plist" << INFOPLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>       <string>StampForge</string>
    <key>CFBundleIdentifier</key> <string>com.cicf.stampforge</string>
    <key>CFBundleVersion</key>    <string>3.0.0</string>
    <key>CFBundleExecutable</key> <string>StampForge</string>
    <key>LSUIElement</key>        <false/>
    <key>CFBundleIconFile</key>   <string>AppIcon</string>
</dict>
</plist>
INFOPLIST
ok ".app bundle created: $APP_DIR"

# ── Shell alias ────────────────────────────────────────
for rcfile in "$HOME/.zshrc" "$HOME/.bash_profile"; do
    if [ -f "$rcfile" ] && ! grep -q "alias stampforge=" "$rcfile"; then
        echo "" >> "$rcfile"
        echo "# StampForge" >> "$rcfile"
        echo "alias stampforge='$LAUNCHER'" >> "$rcfile"
    fi
done
ok "Shell alias 'stampforge' added"

echo ""
echo -e "  ${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "  ${GREEN}║  Installation complete!                          ║${NC}"
echo -e "  ${GREEN}║                                                  ║${NC}"
echo -e "  ${GREEN}║  Launch: Open StampForge from ~/Applications     ║${NC}"
echo -e "  ${GREEN}║  Or run: stampforge  (new terminal)              ║${NC}"
echo -e "  ${GREEN}║  Browser: http://localhost:$PORT                    ║${NC}"
echo -e "  ${GREEN}║                                                  ║${NC}"
echo -e "  ${GREEN}║  First run: OctoPrint setup wizard appears.      ║${NC}"
echo -e "  ${GREEN}║  After setup → StampForge tab is visible.        ║${NC}"
echo -e "  ${GREEN}║                                                  ║${NC}"
echo -e "  ${GREEN}║  NOTE: USB printing requires Chrome or Edge.     ║${NC}"
echo -e "  ${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

read -p "  Launch StampForge now? [Y/n] " ans
if [[ "${ans,,}" != "n" ]]; then
    bash "$LAUNCHER"
fi
echo ""
