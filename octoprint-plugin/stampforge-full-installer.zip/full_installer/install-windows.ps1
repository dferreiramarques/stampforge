# ══════════════════════════════════════════════════════
#  StampForge + OctoPrint — Full Installer
#  Windows 10/11 (PowerShell 5+)
#  Run as Administrator
# ══════════════════════════════════════════════════════

param([switch]$Silent)

$ErrorActionPreference = "Stop"
$PORT = 5000
$INSTALL_DIR = "$env:LOCALAPPDATA\OctoPrint"
$VENV = "$INSTALL_DIR\venv"
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

function ok   { param($m) Write-Host "  [OK] $m" -ForegroundColor Green }
function warn { param($m) Write-Host "  [!]  $m" -ForegroundColor Yellow }
function info { param($m) Write-Host "  [...] $m" -ForegroundColor Cyan }
function err  { param($m) Write-Host "  [X]  $m" -ForegroundColor Red }

Clear-Host
Write-Host ""
Write-Host "  StampForge + OctoPrint — Full Installer" -ForegroundColor Cyan
Write-Host "  CDI Portugal / Centro de Inovacao Carlos Fiolhais"
Write-Host ""

# ── Check Administrator ────────────────────────────────
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    warn "Not running as Administrator. Some steps may fail."
    warn "Right-click install-windows.ps1 → Run with PowerShell as Administrator"
    Read-Host "  Press Enter to continue anyway, or Ctrl+C to cancel"
}

# ── Check / Install Python ────────────────────────────
info "Checking Python..."
$pyCmd = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd --version 2>&1
        if ($ver -match "Python 3\.(8|9|10|11|12)") {
            $pyCmd = $cmd
            ok "Python found: $ver"
            break
        }
    } catch {}
}

if (-not $pyCmd) {
    warn "Python 3.8+ not found. Downloading installer..."
    $pyUrl = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    $pyInstaller = "$env:TEMP\python-installer.exe"
    info "Downloading Python 3.11..."
    Invoke-WebRequest -Uri $pyUrl -OutFile $pyInstaller -UseBasicParsing
    info "Installing Python (silent)..."
    Start-Process -FilePath $pyInstaller -Args "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1" -Wait
    Remove-Item $pyInstaller -Force
    # Refresh PATH
    $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH","User") + ";" + [System.Environment]::GetEnvironmentVariable("PATH","Machine")
    $pyCmd = "python"
    ok "Python installed"
}

# ── Create venv ────────────────────────────────────────
if (-not (Test-Path $VENV)) {
    info "Creating virtual environment at $VENV..."
    New-Item -ItemType Directory -Force -Path $INSTALL_DIR | Out-Null
    & $pyCmd -m venv $VENV
    ok "Virtual environment created"
} else {
    ok "Virtual environment exists"
}

$PY  = "$VENV\Scripts\python.exe"
$PIP = "$VENV\Scripts\pip.exe"

# ── Install OctoPrint ─────────────────────────────────
info "Installing OctoPrint (this may take a few minutes)..."
& $PIP install --upgrade pip setuptools wheel --quiet
& $PIP install "OctoPrint>=1.9.0" --quiet
$octoVer = & $PY -c "import octoprint; print(octoprint.__version__)"
ok "OctoPrint $octoVer installed"

# ── Install StampForge plugin ──────────────────────────
info "Installing StampForge plugin..."
& $PIP install --no-deps "$SCRIPT_DIR\plugin" --force-reinstall --quiet
ok "StampForge plugin installed"

# ── Create Windows Task / startup script ──────────────
$startScript = "$INSTALL_DIR\start-stampforge.bat"
@"
@echo off
echo Starting StampForge + OctoPrint...
start "" "$VENV\Scripts\octoprint.exe" serve --port $PORT
timeout /t 4 /nobreak >nul
start "" http://localhost:$PORT
"@ | Set-Content -Path $startScript -Encoding UTF8
ok "Start script created: $startScript"

# ── Desktop shortcut ───────────────────────────────────
$desktop = [Environment]::GetFolderPath("Desktop")
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut("$desktop\StampForge.lnk")
$shortcut.TargetPath = $startScript
$shortcut.WorkingDirectory = $INSTALL_DIR
$shortcut.Description = "StampForge + OctoPrint — 3D Stamp Designer"
$shortcut.IconLocation = "shell32.dll,22"
$shortcut.Save()
ok "Desktop shortcut created"

# ── Add to Start Menu ──────────────────────────────────
$startMenu = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
$startShortcut = $shell.CreateShortcut("$startMenu\StampForge.lnk")
$startShortcut.TargetPath = $startScript
$startShortcut.WorkingDirectory = $INSTALL_DIR
$startShortcut.Description = "StampForge + OctoPrint"
$startShortcut.IconLocation = "shell32.dll,22"
$startShortcut.Save()
ok "Start Menu entry created"

# ── Windows Firewall rule ──────────────────────────────
try {
    netsh advfirewall firewall add rule name="OctoPrint StampForge" `
        dir=in action=allow protocol=TCP localport=$PORT | Out-Null
    ok "Firewall rule added for port $PORT"
} catch {
    warn "Could not add firewall rule (run as Admin to enable network access)"
}

Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║  Installation complete!                          ║" -ForegroundColor Green
Write-Host "  ║                                                  ║" -ForegroundColor Green
Write-Host "  ║  Launch: Double-click StampForge on Desktop      ║" -ForegroundColor Green
Write-Host "  ║  Or run: $startScript" -ForegroundColor Green
Write-Host "  ║                                                  ║" -ForegroundColor Green
Write-Host "  ║  Browser: http://localhost:$PORT                    ║" -ForegroundColor Green
Write-Host "  ║                                                  ║" -ForegroundColor Green
Write-Host "  ║  First run: OctoPrint setup wizard appears.      ║" -ForegroundColor Green
Write-Host "  ║  After setup → StampForge tab is visible.        ║" -ForegroundColor Green
Write-Host "  ╚══════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

$launch = Read-Host "  Launch StampForge now? [Y/n]"
if ($launch -ne "n" -and $launch -ne "N") {
    Start-Process $startScript
}
